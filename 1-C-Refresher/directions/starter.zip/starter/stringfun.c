#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#define BUFFER_SZ 50

//prototypes
void usage(char *);
void print_buff(char *, int);
int  setup_buff(char *, char *, int);

//prototypes for functions to handle required functionality
int  count_words(char *, int, int);
//add additional prototypes here

    //TODO: #4:  Implement the setup buff as per the directions

int setup_buff(char *buff, char *user_str, int len) {
    int i = 0, j = 0, user_str_len = 0;

    while (*(user_str + user_str_len) != '\0') {
        user_str_len++;
    }

    // Check if user_str_len exceeds the buffer size
    if (user_str_len >= len) {
        return -1;
    }

    int in_whitespace = 0;
    while (*(user_str + i) != '\0' && j < len) {
        char current_char = *(user_str + i);
        if (current_char == ' ' || current_char == '\t') {
            if (!in_whitespace) {
                *(buff + j++) = ' ';
                in_whitespace = 1;
            }
        } else {
            *(buff + j++) = current_char;
            in_whitespace = 0;
        }
        i++;
    }

    while (j < len) {
        *(buff + j++) = '.';
    }

    return user_str_len;
}

void print_buff(char *buff, int len){
    printf("Buffer:  [");
    for (int i = 0; i < len; i++) {
        putchar(*(buff + i));
    }
    putchar(']');
    putchar('\n');
}

void usage(char *exename){
    printf("usage: %s [-h|c|r|w|x] \"string\" [other args]\n", exename);

}

int count_words(char *buff, int len, int str_len) {
    int word_count = 0;
    int in_word = 0;

    for (int i = 0; i < str_len; i++) {
        if (*(buff + i) == ' ' || *(buff + i) == '\t') {
            in_word = 0;
        } else {
            if (!in_word) {
                word_count++;
                in_word = 1;
            }
        }
    }
    return word_count;
}

//ADD OTHER HELPER FUNCTIONS HERE FOR OTHER REQUIRED PROGRAM OPTIONS

int main(int argc, char *argv[]){

    char *buff;             //placehoder for the internal buffer
    char *input_string;     //holds the string provided by the user on cmd line
    char opt;               //used to capture user option from cmd line
    int  rc;                //used for return codes
    int  user_str_len;      //length of user supplied string

    //TODO:  #1. WHY IS THIS SAFE, aka what if arv[1] does not exist?
    //      PLACE A COMMENT BLOCK HERE EXPLAINING
    /*
    This is safe becauce it handles cases where the user does not provide a enough arguments. 
    "argc < 2" verifies that the user entered at least one argument besides the program name. 
    The "*argv[1] != '-'" ensures the first character of the provided argument is a valid 
    option flag, by using this "'-'". These safety checks ensures we are getting the correct 
    input from the user. If the input is invalid, the program prints usage instructions and 
    exits with an error, preventing crashes or unexpected behavior.
    */
    if ((argc < 2) || (*argv[1] != '-')){
        usage(argv[0]);
        exit(1);
    }

    opt = (char)*(argv[1]+1);   //get the option flag

    //handle the help flag and then exit normally
    if (opt == 'h'){
        usage(argv[0]);
        exit(0);
    }

    //WE NOW WILL HANDLE THE REQUIRED OPERATIONS

    //TODO:  #2 Document the purpose of the if statement below
    //      PLACE A COMMENT BLOCK HERE EXPLAINING
    /*
    The "if (argc < 3)"" statement ensures that the user has entered both an option flag 
    and a string to operate on, similar to #1. It checks whether there are at least three arguments, 
    where the first is the program name, the second is the option flag like (-h, -c), 
    and the third is the string input for processing. If there are fewer than three arguments, 
    it means the user didn't provide the required string. If the input is invalid it will follow the
    same with #1. The program prints usage instructions and exits with an error, preventing crashes or unexpected behavior.
    */
    if (argc < 3){
        usage(argv[0]);
        exit(1);
    }

    input_string = argv[2]; //capture the user input string

    //TODO:  #3 Allocate space for the buffer using malloc and
    //          handle error if malloc fails by exiting with a 
    //          return code of 99
    // CODE GOES HERE FOR #3
    buff = (char *)malloc(BUFFER_SZ * sizeof(char));
    if (buff == NULL) {
        printf("Error: Memory allocation failed!\n");
        exit(99);
    }

    user_str_len = setup_buff(buff, input_string, BUFFER_SZ);     //see todos
    if (user_str_len < 0){
        printf("Error setting up buffer, error = %d", user_str_len);
        exit(2);
    }

    switch (opt){
        case 'c':
            rc = count_words(buff, BUFFER_SZ, user_str_len);  //you need to implement
            if (rc < 0){
                printf("Error counting words, rc = %d", rc);
                exit(2);
            }
            printf("Word Count: %d\n", rc);
            break;

        //TODO:  #5 Implement the other cases for 'r' and 'w' by extending
        //       the case statement options
        case 'r':
            char *start = buff;
            char *end = buff + user_str_len - 1;

            //this swaps the characters from the start and end and moves towards the center
            while (start < end) {
                char temp = *start;
                *start = *end;
                *end = temp;
                start++;
                end--;
            }

            //prints the reversed string
            printf("Reversed String: ");
            for (int i = 0; i < user_str_len; i++) {
                putchar(*(buff + i));
            }
            putchar('\n');
            break;

        case 'w':
            printf("Word Print\n");
            printf("----------\n");

            int word_num = 1;
            int word_length = 0;
            char *current_char = buff;

            for (int i = 0; i < user_str_len; i++) {
                if (*current_char != ' ' && *current_char != '\t') {
                    word_length++;
                } else if (word_length > 0) {
                    printf("%d. ", word_num++);
                    for (int j = i - word_length; j < i; j++) {
                        putchar(*(buff + j));
                    }
                    printf(" (%d)\n", word_length);
                    word_length = 0;
                }
                current_char++;
            }

            if (word_length > 0) {
                printf("%d. ", word_num++);
                for (int j = user_str_len - word_length; j < user_str_len; j++) {
                    putchar(*(buff + j));
                }
                printf(" (%d)\n", word_length);
            }
            printf("\nNumber of words returned: %d\n", count_words(buff, BUFFER_SZ, user_str_len));
            break;

        default:
            usage(argv[0]);
            exit(1);
    }

    //TODO:  #6 Dont forget to free your buffer before exiting
    print_buff(buff,BUFFER_SZ);
    free(buff);
    exit(0);
}

//TODO:  #7  Notice all of the helper functions provided in the 
//          starter take both the buffer as well as the length.  Why
//          do you think providing both the pointer and the length
//          is a good practice, after all we know from main() that 
//          the buff variable will have exactly 50 bytes?
//  
//          PLACE YOUR ANSWER HERE
/*
Providing both the pointer and the length to the helper functions is a 
good practice because it enhances code readability, maintains function modularity, 
and ensures error handling is more explicit. Even though buff always has 50 bytes 
allocated in this context, a separate length parameter makes the functions more reusable 
and flexible for varying buffer sizes. It also prevents potential issues if buffer size changes in the future.
*/